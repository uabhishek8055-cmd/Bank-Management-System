package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CardScreen extends JFrame implements ActionListener {

    JButton loginBtn;

    CardScreen(String card, String pin){

        setTitle("Pragati Bank - Account Created");
        setLayout(null);
        getContentPane().setBackground(new Color(30,30,60));

        JLabel heading = new JLabel("PRAGATI BANK");
        heading.setFont(new Font("System",Font.BOLD,30));
        heading.setForeground(Color.WHITE);
        heading.setBounds(220,40,400,40);
        add(heading);

        JLabel success = new JLabel("ACCOUNT CREATED SUCCESSFULLY");
        success.setFont(new Font("System",Font.BOLD,18));
        success.setForeground(Color.GREEN);
        success.setBounds(200,100,400,30);
        add(success);

        JLabel cardLabel = new JLabel("YOUR CARD NUMBER");
        cardLabel.setForeground(Color.WHITE);
        cardLabel.setBounds(250,160,200,20);
        add(cardLabel);

        JLabel cardNo = new JLabel(card);
        cardNo.setFont(new Font("Monospaced",Font.BOLD,18));
        cardNo.setForeground(Color.YELLOW);
        cardNo.setBounds(210,185,300,25);
        add(cardNo);

        JLabel pinLabel = new JLabel("YOUR PIN");
        pinLabel.setForeground(Color.WHITE);
        pinLabel.setBounds(290,230,100,20);
        add(pinLabel);

        JLabel pinNo = new JLabel(pin);
        pinNo.setFont(new Font("Monospaced",Font.BOLD,22));
        pinNo.setForeground(Color.CYAN);
        pinNo.setBounds(315,255,100,30);
        add(pinNo);

        JLabel note = new JLabel("Keep your card & PIN safe");
        note.setForeground(Color.LIGHT_GRAY);
        note.setBounds(250,310,250,20);
        add(note);

        loginBtn = new JButton("GO TO LOGIN");
        loginBtn.setBounds(270,360,160,35);
        loginBtn.setBackground(new Color(0,120,215));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.addActionListener(this);
        add(loginBtn);

        setSize(700,500);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new LOGIN().setVisible(true);
    }
}
