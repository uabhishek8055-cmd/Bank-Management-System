package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.util.Date;

public class ReceiptWindow extends JFrame {

    ReceiptWindow(String pin,String type,String amount,String balance){

        setTitle("Transaction Receipt");
        setLayout(null);

        JTextArea receipt = new JTextArea();
        receipt.setFont(new Font("Monospaced",Font.PLAIN,14));
        receipt.setEditable(false);

        receipt.append("\n");
        receipt.append("       PRAGATI BANK ATM RECEIPT\n");
        receipt.append("--------------------------------------\n");
        receipt.append("Date: "+new Date()+"\n\n");
        receipt.append("Transaction: "+type+"\n");
        receipt.append("Amount: ₹"+amount+"\n");
        receipt.append("Remaining Balance: ₹"+balance+"\n");
        receipt.append("--------------------------------------\n");
        receipt.append("Thank you for banking with us\n");

        JScrollPane pane = new JScrollPane(receipt);
        pane.setBounds(20,20,360,260);
        add(pane);

        JButton close = new JButton("Close");
        close.setBounds(150,300,120,30);
        add(close);

        close.addActionListener(e->setVisible(false));

        setSize(420,400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
