package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Transactions extends JFrame implements ActionListener {

    JButton deposit, withdraw, fastcash, ministatement, balance, pinchange, exit;
    String pin;

    Transactions(String pin){
        this.pin = pin;

        setTitle("Pragati Bank Dashboard");
        setSize(900,600);
        setLocationRelativeTo(null);

        JPanel bg = new JPanel(null);
        bg.setBackground(new Color(18,34,63));
        add(bg);

        JLabel heading = new JLabel("PRAGATI BANK ATM");
        heading.setFont(new Font("Segoe UI",Font.BOLD,28));
        heading.setForeground(Color.WHITE);
        heading.setBounds(300,50,400,40);
        bg.add(heading);

        deposit = createButton("Deposit",200,180);
        withdraw = createButton("Withdraw",450,180);
        fastcash = createButton("Fast Cash",200,250);
        ministatement = createButton("Mini Statement",450,250);
        balance = createButton("Balance Enquiry",200,320);
        pinchange = createButton("Change PIN",450,320);
        exit = createButton("Exit",325,400);

        bg.add(deposit); bg.add(withdraw); bg.add(fastcash);
        bg.add(ministatement); bg.add(balance);
        bg.add(pinchange); bg.add(exit);

        deposit.addActionListener(this);
        withdraw.addActionListener(this);
        fastcash.addActionListener(this);
        ministatement.addActionListener(this);
        balance.addActionListener(this);
        pinchange.addActionListener(this);
        exit.addActionListener(this);

        setVisible(true);
    }

    JButton createButton(String text,int x,int y){
        JButton btn = new JButton(text);
        btn.setBounds(x,y,200,40);
        btn.setBackground(Color.WHITE);
        btn.setFont(new Font("Segoe UI",Font.BOLD,14));
        btn.setFocusPainted(false);
        return btn;
    }

    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==deposit){
            new Deposit(pin);
        }
        else if(ae.getSource()==withdraw){
            new Withdrawl(pin);
        }
        else if(ae.getSource()==fastcash){
            new FastCash(pin);
        }
        else if(ae.getSource()==ministatement){
            new MiniStatement(pin);
        }
        else if(ae.getSource()==balance){
            new BalanceEnquiry(pin);
        }
        else if(ae.getSource()==pinchange){
            new PinChange(pin);
        }
        else if(ae.getSource()==exit){
            System.exit(0);
        }
    }
}