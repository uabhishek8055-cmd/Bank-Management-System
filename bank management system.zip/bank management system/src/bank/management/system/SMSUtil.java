package bank.management.system;

import javax.swing.*;

public class SMSUtil {

    public static void sendSMS(String msg){
        JOptionPane.showMessageDialog(null,
                "📱 Pragati Bank SMS Alert\n\n"+msg,
                "SMS Notification",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
