package bank.management.system;

import javax.swing.*;
import java.awt.*;

public class LoadingScreen extends JFrame {

    JProgressBar bar;

    LoadingScreen(){

        setTitle("Loading...");
        setSize(400,200);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel text=new JLabel("Initializing ATM...");
        text.setBounds(130,40,200,30);
        add(text);

        bar=new JProgressBar();
        bar.setBounds(50,90,300,25);
        add(bar);

        setVisible(true);

        new Thread(){
            public void run(){
                try{
                    for(int i=0;i<=100;i++){
                        bar.setValue(i);
                        Thread.sleep(20);
                    }
                    dispose();
                    new CardInsertScreen();
                }catch(Exception e){}
            }
        }.start();
    }
}