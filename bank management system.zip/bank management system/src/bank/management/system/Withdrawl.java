package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class Withdrawl extends JFrame implements ActionListener {

    JTextField amount;
    JButton withdraw, back;
    String pin;

    Withdrawl(String pin){
        this.pin=pin;

        setLayout(null);

        JLabel text=new JLabel("Enter Amount to Withdraw");
        text.setFont(new Font("System",Font.BOLD,16));
        text.setBounds(170,80,300,30);
        add(text);

        amount=new JTextField();
        amount.setBounds(200,130,200,30);
        add(amount);

        withdraw=new JButton("Withdraw");
        withdraw.setBounds(200,180,90,30);
        withdraw.addActionListener(this);
        add(withdraw);

        back=new JButton("Back");
        back.setBounds(310,180,90,30);
        back.addActionListener(this);
        add(back);

        setSize(600,350);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==withdraw){

            String amt = amount.getText().trim();

            if(amt.isEmpty()){
                JOptionPane.showMessageDialog(null,"Enter amount");
                return;
            }

            if(!amt.matches("\\d+")){
                JOptionPane.showMessageDialog(null,"Enter valid amount");
                return;
            }

            int withdrawAmount = Integer.parseInt(amt);
            int balance = 0;

            try{
                Conn c=new Conn();

                ResultSet rs=c.s.executeQuery("SELECT * FROM bank WHERE pin='"+pin+"'");

                while(rs.next()){
                    if(rs.getString("type").equals("Deposit"))
                        balance+=rs.getInt("amount");
                    else
                        balance-=rs.getInt("amount");
                }

                if(balance < withdrawAmount){
                    JOptionPane.showMessageDialog(null,"Insufficient Balance");
                    return;
                }

                String date=new Date().toString();

                c.s.executeUpdate(
                        "INSERT INTO bank VALUES('"+pin+"','"+date+"','Withdraw','"+withdrawAmount+"')"
                );

                int newBalance = balance - withdrawAmount;

                // 📱 SMS
                SMSUtil.sendSMS(
                        "₹"+withdrawAmount+" debited from your account.\nRemaining Balance: ₹"+newBalance
                );

                JOptionPane.showMessageDialog(null,"Withdrawal Successful");

                setVisible(false);
                new Transactions(pin).setVisible(true);

            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Database Error");
                e.printStackTrace();
            }
        }

        if(ae.getSource()==back){
            setVisible(false);
            new Transactions(pin).setVisible(true);
        }
    }
}
