package bank.management.system;

import java.sql.*;

public class Conn {

    Connection c;
    Statement s;

    public Conn(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 👇 PASSWORD yahan change karna agar root password alag hai
            c = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/bankmanagementsystem",
                    "root",
                    "abhi1241"
            );

            s = c.createStatement();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
