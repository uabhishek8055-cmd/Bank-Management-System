package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GlassLogin extends JFrame implements ActionListener {

    JTextField card;
    JPasswordField pin;
    JButton login;

    GlassLogin(){

        setTitle("Pragati Bank ATM");
        setSize(900,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // background gradient
        JPanel bg = new JPanel(){
            protected void paintComponent(Graphics g){
                super.paintComponent(g);
                Graphics2D g2=(Graphics2D)g;
                GradientPaint gp=new GradientPaint(
                        0,0,new Color(10,30,60),
                        0,getHeight(),new Color(0,0,0));
                g2.setPaint(gp);
                g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        bg.setLayout(null);
        setContentPane(bg);

        // glass panel
        JPanel glass = new JPanel(){
            protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g;
                g2.setColor(new Color(255,255,255,80));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),30,30);
            }
        };
        glass.setLayout(null);
        glass.setBounds(280,120,330,300);
        bg.add(glass);

        JLabel title=new JLabel("ATM LOGIN");
        title.setFont(new Font("Segoe UI",Font.BOLD,22));
        title.setBounds(100,20,200,30);
        glass.add(title);

        JLabel c=new JLabel("Card:");
        c.setBounds(30,80,100,25);
        glass.add(c);

        card=new JTextField();
        card.setBounds(110,80,180,25);
        glass.add(card);

        JLabel p=new JLabel("PIN:");
        p.setBounds(30,130,100,25);
        glass.add(p);

        pin=new JPasswordField();
        pin.setBounds(110,130,180,25);
        glass.add(pin);

        login=new JButton("LOGIN");
        login.setBounds(110,190,120,35);
        login.addActionListener(this);
        glass.add(login);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        new LoadingScreen();
        dispose();
    }

    public static void main(String[] args){
        new GlassLogin();
    }
}