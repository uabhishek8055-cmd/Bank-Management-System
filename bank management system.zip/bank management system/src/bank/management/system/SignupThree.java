package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignupThree extends JFrame implements ActionListener {

    JButton submit;
    String formno;

    SignupThree(String formno){

        this.formno=formno;

        setTitle("Signup - Page 3");
        setSize(600,400);
        setLocationRelativeTo(null);

        WatermarkPanel panel = new WatermarkPanel();
        panel.setLayout(null);
        setContentPane(panel);

        JLabel title = new JLabel("ACCOUNT CREATED SUCCESSFULLY");
        title.setBounds(100,100,400,30);
        title.setFont(new Font("Arial",Font.BOLD,16));
        panel.add(title);

        submit = new JButton("GO TO LOGIN");
        submit.setBounds(200,200,150,35);
        submit.addActionListener(this);
        panel.add(submit);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        new LOGIN();
        setVisible(false);
    }
}