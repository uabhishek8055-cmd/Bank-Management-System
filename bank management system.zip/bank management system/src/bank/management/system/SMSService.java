package bank.management.system;

import javax.swing.*;

public class SMSService {

    public static void sendSMS(String mobile,String msg){
        JOptionPane.showMessageDialog(null,
                "📱 SMS sent to "+mobile+"\n\n"+msg);
    }
}
