package bank.management.system;

import javax.swing.*;
import java.awt.*;

public class UITheme {

    // Gradient background panel
    public static JPanel gradientPanel(){
        return new JPanel(){
            protected void paintComponent(Graphics g){
                super.paintComponent(g);
                Graphics2D g2=(Graphics2D)g;
                GradientPaint gp=new GradientPaint(
                        0,0,new Color(10,30,60),
                        0,getHeight(),new Color(25,60,120));
                g2.setPaint(gp);
                g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
    }

    // Rounded button style
    public static JButton roundedButton(String text){
        JButton b=new JButton(text);
        b.setFont(new Font("Segoe UI",Font.BOLD,14));
        b.setForeground(Color.WHITE);
        b.setBackground(new Color(30,80,180));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));

        b.addMouseListener(new java.awt.event.MouseAdapter(){
            public void mouseEntered(java.awt.event.MouseEvent evt){
                b.setBackground(new Color(50,110,220));
            }
            public void mouseExited(java.awt.event.MouseEvent evt){
                b.setBackground(new Color(30,80,180));
            }
        });

        return b;
    }

    // Card panel style
    public static JPanel card(){
        JPanel p=new JPanel();
        p.setBackground(Color.WHITE);
        p.setLayout(null);
        p.setBorder(BorderFactory.createLineBorder(new Color(200,200,200),1,true));
        return p;
    }
}