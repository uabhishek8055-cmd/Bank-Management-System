package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class MiniStatement extends JFrame {

    MiniStatement(String pin){

        setTitle("Mini Statement");
        setLayout(null);

        JTextArea area=new JTextArea();
        area.setFont(new Font("Monospaced",Font.PLAIN,13));
        area.setEditable(false);

        JScrollPane pane=new JScrollPane(area);
        pane.setBounds(20,20,440,300);
        add(pane);

        try{
            Conn c=new Conn();
            ResultSet rs=c.s.executeQuery(
                "SELECT * FROM bank WHERE pin='"+pin+"' ORDER BY date DESC"
            );

            area.append("DATE                TYPE      AMOUNT\n");
            area.append("-------------------------------------------\n");

            while(rs.next()){
                area.append(
                    rs.getString("date")+"   "+
                    rs.getString("type")+"   ₹"+
                    rs.getString("amount")+"\n"
                );
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        JButton back=new JButton("Back");
        back.setBounds(180,330,120,30);
        add(back);

        back.addActionListener(e->{
            setVisible(false);
            new Transactions(pin).setVisible(true);
        });

        setSize(500,420);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
