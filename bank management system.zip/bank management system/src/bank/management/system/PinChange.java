package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class PinChange extends JFrame implements ActionListener {

    JPasswordField oldpinField, newpinField, repinField;
    JButton change, back;
    String pinnumber;

    PinChange(String pinnumber) {
        this.pinnumber = pinnumber;

        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);

        JLabel image = new JLabel(i3);
        image.setBounds(0,0,900,900);
        add(image);

        JLabel text = new JLabel("CHANGE YOUR PIN");
        text.setForeground(Color.WHITE);
        text.setFont(new Font("System",Font.BOLD,18));
        text.setBounds(250,280,500,35);
        image.add(text);

        JLabel oldpin = new JLabel("Enter Old PIN:");
        oldpin.setForeground(Color.WHITE);
        oldpin.setBounds(165,320,200,25);
        image.add(oldpin);

        oldpinField = new JPasswordField();
        oldpinField.setBounds(330,320,180,25);
        image.add(oldpinField);

        JLabel newpin = new JLabel("Enter New PIN:");
        newpin.setForeground(Color.WHITE);
        newpin.setBounds(165,360,200,25);
        image.add(newpin);

        newpinField = new JPasswordField();
        newpinField.setBounds(330,360,180,25);
        image.add(newpinField);

        JLabel repin = new JLabel("Re-Enter New PIN:");
        repin.setForeground(Color.WHITE);
        repin.setBounds(165,400,200,25);
        image.add(repin);

        repinField = new JPasswordField();
        repinField.setBounds(330,400,180,25);
        image.add(repinField);

        change = new JButton("CHANGE");
        change.setBounds(355,485,150,30);
        change.addActionListener(this);
        image.add(change);

        back = new JButton("BACK");
        back.setBounds(355,520,150,30);
        back.addActionListener(this);
        image.add(back);

        setSize(900,900);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==change){

            String oldpin = new String(oldpinField.getPassword());
            String newpin = new String(newpinField.getPassword());
            String repin = new String(repinField.getPassword());

            if(oldpin.equals("") || newpin.equals("") || repin.equals("")){
                JOptionPane.showMessageDialog(null,"Fill all fields");
                return;
            }

            if(newpin.length()!=4 || !newpin.matches("\\d+")){
                JOptionPane.showMessageDialog(null,"PIN must be 4 digits");
                return;
            }

            if(!newpin.equals(repin)){
                JOptionPane.showMessageDialog(null,"New PIN does not match");
                return;
            }

            try{
                Conn c = new Conn();

                // ✔ verify old PIN belongs to logged user
                PreparedStatement check = c.c.prepareStatement(
                        "SELECT * FROM login WHERE pin=?"
                );
                check.setString(1,pinnumber);

                ResultSet rs = check.executeQuery();
                if(!rs.next()){
                    JOptionPane.showMessageDialog(null,"Session Error");
                    return;
                }

                // ✔ update login
                PreparedStatement ps2 = c.c.prepareStatement(
                        "UPDATE login SET pin=? WHERE pin=?"
                );
                ps2.setString(1,newpin);
                ps2.setString(2,pinnumber);
                ps2.executeUpdate();

                // ✔ update bank history
                PreparedStatement ps3 = c.c.prepareStatement(
                        "UPDATE bank SET pin=? WHERE pin=?"
                );
                ps3.setString(1,newpin);
                ps3.setString(2,pinnumber);
                ps3.executeUpdate();

                JOptionPane.showMessageDialog(null,"PIN Changed Successfully");

                setVisible(false);
                new Transactions(newpin).setVisible(true);

            }catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null,"Database Error");
            }
        }

        else if(ae.getSource()==back){
            setVisible(false);
            new Transactions(pinnumber).setVisible(true);
        }
    }
}
