package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class EmailOTP extends JFrame implements ActionListener {

    JTextField otpField;
    JButton verify;
    String generatedOTP, formno, email;

    EmailOTP(String formno,String email){
        this.formno=formno;
        this.email=email;

        setLayout(null);

        JLabel msg=new JLabel("OTP sent to: "+email);
        msg.setBounds(120,80,300,30);
        add(msg);

        // generate OTP
        Random r=new Random();
        generatedOTP=""+(1000+r.nextInt(9000));

        // simulation popup
        JOptionPane.showMessageDialog(null,
                "📧 Email OTP: "+generatedOTP+
                "\n(Email Simulation)");

        JLabel enter=new JLabel("Enter OTP:");
        enter.setBounds(120,140,100,30);
        add(enter);

        otpField=new JTextField();
        otpField.setBounds(220,140,150,30);
        add(otpField);

        verify=new JButton("Verify");
        verify.setBounds(220,200,100,30);
        verify.addActionListener(this);
        add(verify);

        setSize(450,350);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){

        if(otpField.getText().equals(generatedOTP)){
            JOptionPane.showMessageDialog(null,"Email Verified ✔");
            new SignupTwo(formno).setVisible(true);
            setVisible(false);
        }else{
            JOptionPane.showMessageDialog(null,"Wrong OTP");
        }
    }
}
