package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignupTwo extends JFrame implements ActionListener {

    JTextField religion,category,income,education,occupation,pan,aadhar;
    JButton next;
    String formno;

    SignupTwo(String formno){

        this.formno=formno;

        setTitle("Signup - Page 2");
        setSize(700,600);
        setLocationRelativeTo(null);

        WatermarkPanel panel = new WatermarkPanel();
        panel.setLayout(null);
        setContentPane(panel);

        religion = addField(panel,"Religion:",100,100);
        category = addField(panel,"Category:",100,140);
        income = addField(panel,"Income:",100,180);
        education = addField(panel,"Education:",100,220);
        occupation = addField(panel,"Occupation:",100,260);
        pan = addField(panel,"PAN:",100,300);
        aadhar = addField(panel,"Aadhar:",100,340);

        next = new JButton("NEXT");
        next.setBounds(300,400,120,35);
        next.addActionListener(this);
        panel.add(next);

        setVisible(true);
    }

    JTextField addField(JPanel p,String label,int x,int y){
        JLabel l=new JLabel(label);
        l.setBounds(x,y,150,25);
        p.add(l);

        JTextField t=new JTextField();
        t.setBounds(x+200,y,200,25);
        p.add(t);
        return t;
    }

    public void actionPerformed(ActionEvent ae){
        new SignupThree(formno);
        setVisible(false);
    }
}