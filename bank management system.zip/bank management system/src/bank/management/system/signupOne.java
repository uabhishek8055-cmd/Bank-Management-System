package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import com.toedter.calendar.JDateChooser;

public class SignupOne extends JFrame implements ActionListener {

    JTextField nameField,fatherField,emailField,addressField,
               cityField,stateField,pinField,mobileField;
    JDateChooser dobChooser;
    JRadioButton male,female,married,unmarried,other;
    JButton next;
    long formNo;

    SignupOne(){

        setTitle("Signup - Page 1");
        setSize(750,700);
        setLocationRelativeTo(null);

        WatermarkPanel panel = new WatermarkPanel();
        panel.setLayout(null);
        setContentPane(panel);

        Random r = new Random();
        formNo = Math.abs((r.nextLong()%9000L)+1000L);

        JLabel title = new JLabel("NEW ACCOUNT APPLICATION");
        title.setBounds(200,30,400,30);
        title.setFont(new Font("Arial",Font.BOLD,20));
        panel.add(title);

        JLabel formLabel = new JLabel("Form No: "+formNo);
        formLabel.setBounds(30,30,200,30);
        panel.add(formLabel);

        addField(panel,"Name:",100,100);
        nameField = addText(panel,300,100);

        addField(panel,"Father Name:",100,140);
        fatherField = addText(panel,300,140);

        addField(panel,"DOB:",100,180);
        dobChooser = new JDateChooser();
        dobChooser.setBounds(300,180,200,25);
        panel.add(dobChooser);

        addField(panel,"Gender:",100,220);
        male = new JRadioButton("Male");
        female = new JRadioButton("Female");
        male.setBounds(300,220,80,30);
        female.setBounds(390,220,100,30);
        panel.add(male); panel.add(female);
        ButtonGroup g = new ButtonGroup();
        g.add(male); g.add(female);

        addField(panel,"Marital:",100,260);
        married = new JRadioButton("Married");
        unmarried = new JRadioButton("Unmarried");
        other = new JRadioButton("Other");
        married.setBounds(300,260,90,30);
        unmarried.setBounds(390,260,110,30);
        other.setBounds(510,260,80,30);
        panel.add(married); panel.add(unmarried); panel.add(other);
        ButtonGroup m = new ButtonGroup();
        m.add(married); m.add(unmarried); m.add(other);

        addField(panel,"Email:",100,300);
        emailField = addText(panel,300,300);

        addField(panel,"Mobile:",100,340);
        mobileField = addText(panel,300,340);

        addField(panel,"Address:",100,380);
        addressField = addText(panel,300,380);

        addField(panel,"City:",100,420);
        cityField = addText(panel,300,420);

        addField(panel,"State:",100,460);
        stateField = addText(panel,300,460);

        addField(panel,"PIN Code:",100,500);
        pinField = addText(panel,300,500);

        next = new JButton("NEXT");
        next.setBounds(320,560,120,35);
        next.addActionListener(this);
        panel.add(next);

        setVisible(true);
    }

    void addField(JPanel p,String text,int x,int y){
        JLabel l=new JLabel(text);
        l.setBounds(x,y,150,25);
        p.add(l);
    }

    JTextField addText(JPanel p,int x,int y){
        JTextField t=new JTextField();
        t.setBounds(x,y,200,25);
        p.add(t);
        return t;
    }

    public void actionPerformed(ActionEvent ae){

        String name=nameField.getText();
        String father=fatherField.getText();

        if(name.isEmpty() || father.isEmpty()){
            JOptionPane.showMessageDialog(null,"Fill required fields");
            return;
        }

        new SignupTwo(""+formNo);
        setVisible(false);
    }
}