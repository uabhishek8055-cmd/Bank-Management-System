package bank.management.system;

import javax.swing.*;
import java.awt.*;

public class CardInsertScreen extends JFrame {

    int y = -100;
    JLabel card;

    CardInsertScreen(){

        setTitle("Insert Card");
        setSize(500,400);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel text=new JLabel("Insert Your Card");
        text.setFont(new Font("Segoe UI",Font.BOLD,20));
        text.setBounds(150,20,200,30);
        add(text);

        card=new JLabel("💳");
        card.setFont(new Font("Segoe UI",Font.PLAIN,80));
        card.setBounds(220,y,100,100);
        add(card);

        setVisible(true);

        new Timer(20,e->{
            y+=2;
            card.setLocation(220,y);
            if(y>=180){
                ((Timer)e.getSource()).stop();
                JOptionPane.showMessageDialog(this,"Card Inserted Successfully");
                dispose();
                new LOGIN();   // original login open
            }
        }).start();
    }
}