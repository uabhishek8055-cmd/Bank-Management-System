package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class FastCash extends JFrame implements ActionListener {

    JButton rs100, rs500, rs1000, rs2000, rs5000, rs10000, back;
    String pinnumber;

    FastCash(String pinnumber){

        this.pinnumber = pinnumber;

        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);

        JLabel image = new JLabel(i3);
        image.setBounds(0,0,900,900);
        add(image);

        JLabel text = new JLabel("SELECT WITHDRAW AMOUNT");
        text.setBounds(250,300,700,35);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("System", Font.BOLD,16));
        image.add(text);

        rs100 = new JButton("100");
        rs500 = new JButton("500");
        rs1000 = new JButton("1000");
        rs2000 = new JButton("2000");
        rs5000 = new JButton("5000");
        rs10000 = new JButton("10000");
        back = new JButton("BACK");

        JButton[] arr = {rs100,rs500,rs1000,rs2000,rs5000,rs10000};

        int x1=170,x2=355,y=415;
        for(int i=0;i<arr.length;i++){
            arr[i].setBounds(i%2==0?x1:x2,y,150,30);
            arr[i].addActionListener(this);
            image.add(arr[i]);
            if(i%2==1) y+=35;
        }

        back.setBounds(355,520,150,30);
        back.addActionListener(this);
        image.add(back);

        setSize(900,900);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==back){
            setVisible(false);
            new Transactions(pinnumber).setVisible(true);
            return;
        }

        String amountStr = ((JButton)ae.getSource()).getText();
        int amount = Integer.parseInt(amountStr);

        try{
            Conn c = new Conn();

            // ✔ current balance check
            int balance = 0;
            ResultSet rs = c.s.executeQuery("SELECT * FROM bank WHERE pin='"+pinnumber+"'");

            while(rs.next()){
                if(rs.getString("type").equals("Deposit")){
                    balance += rs.getInt("amount");
                }else{
                    balance -= rs.getInt("amount");
                }
            }

            if(balance < amount){
                JOptionPane.showMessageDialog(null,"Insufficient Balance");
                return;
            }

            // ✔ insert withdrawal
            String date = new Date().toString();
            c.s.executeUpdate(
                "INSERT INTO bank VALUES('"+pinnumber+"','"+date+"','Withdraw','"+amount+"')"
            );

            JOptionPane.showMessageDialog(null,"₹ "+amount+" Withdrawn Successfully");

            setVisible(false);
            new Transactions(pinnumber).setVisible(true);

        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Database Error (Check Conn.java)");
            e.printStackTrace();
        }
    }
}
