package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class BalanceEnquiry extends JFrame {

    BalanceEnquiry(String pin){

        setTitle("Pragati Bank - Balance Enquiry");
        setLayout(null);

        JLabel heading = new JLabel("CURRENT ACCOUNT BALANCE");
        heading.setFont(new Font("System",Font.BOLD,22));
        heading.setBounds(180,40,400,30);
        add(heading);

        int balance = 0;

        try{
            Conn c=new Conn();
            ResultSet rs=c.s.executeQuery("SELECT * FROM bank WHERE pin='"+pin+"'");

            while(rs.next()){
                if(rs.getString("type").equals("Deposit"))
                    balance+=rs.getInt("amount");
                else
                    balance-=rs.getInt("amount");
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        JLabel amount = new JLabel("₹ "+balance);
        amount.setFont(new Font("System",Font.BOLD,36));
        amount.setBounds(300,120,300,40);
        add(amount);

        JButton back = new JButton("Back");
        back.setBounds(330,200,120,35);
        add(back);

        back.addActionListener(e->{
            setVisible(false);
            new Transactions(pin).setVisible(true);
        });

        setSize(800,350);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
