package bank.management.system;

import javax.swing.*;
import java.awt.*;

public class WatermarkPanel extends JPanel {

    private Image logo;

    public WatermarkPanel() {

        // IMPORTANT → panel transparent
        setOpaque(false);

        // logo load from icons folder
        ImageIcon icon = new ImageIcon(
            getClass().getResource("/icons/icons/Pragati logo.png")
        );

        logo = icon.getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (logo != null) {
            Graphics2D g2 = (Graphics2D) g.create();

            // opacity set (0.0f invisible → 1.0f full)
            g2.setComposite(AlphaComposite.getInstance(
                    AlphaComposite.SRC_OVER, 0.08f));   // 🔥 watermark opacity

            int w = logo.getWidth(null);
            int h = logo.getHeight(null);

            // center watermark
            int x = (getWidth() - w) / 2;
            int y = (getHeight() - h) / 2;

            g2.drawImage(logo, x, y, this);
            g2.dispose();
        }
    }
}