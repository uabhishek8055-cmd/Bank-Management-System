package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LOGIN extends JFrame implements ActionListener {

    JButton login, signup, clear;
    JTextField cardTextField;
    JPasswordField pinTextField;

    LOGIN() {

        setTitle("Pragati Bank ATM");
        setSize(800,500);
        setLocationRelativeTo(null);

        // ✅ Watermark background
        WatermarkPanel panel = new WatermarkPanel();
        panel.setLayout(null);
        setContentPane(panel);

        // ✅ BANK LOGO TOP
        try {
            ImageIcon logoIcon =
                new ImageIcon(getClass().getResource("/icons/icons/pragati logo.png"));

            Image img = logoIcon.getImage().getScaledInstance(120,120,Image.SCALE_SMOOTH);
            JLabel logo = new JLabel(new ImageIcon(img));
            logo.setBounds(330,10,120,120);
            panel.add(logo);

        } catch(Exception e) {
            System.out.println("Logo not found");
        }

        JLabel text = new JLabel("PRAGATI BANK ATM");
        text.setFont(new Font("Raleway",Font.BOLD,30));
        text.setBounds(240,130,400,40);
        panel.add(text);

        JLabel cardno = new JLabel("Card Number:");
        cardno.setBounds(200,200,150,30);
        panel.add(cardno);

        cardTextField = new JTextField();
        cardTextField.setBounds(350,200,200,30);
        panel.add(cardTextField);

        JLabel pin = new JLabel("PIN:");
        pin.setBounds(200,250,150,30);
        panel.add(pin);

        pinTextField = new JPasswordField();
        pinTextField.setBounds(350,250,200,30);
        panel.add(pinTextField);

        login = new JButton("LOGIN");
        login.setBounds(250,320,120,35);
        login.addActionListener(this);
        panel.add(login);

        clear = new JButton("CLEAR");
        clear.setBounds(400,320,120,35);
        clear.addActionListener(this);
        panel.add(clear);

        signup = new JButton("SIGN UP");
        signup.setBounds(300,370,150,35);
        signup.addActionListener(this);
        panel.add(signup);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==clear){
            cardTextField.setText("");
            pinTextField.setText("");
        }

        else if(ae.getSource()==login){

            String cardnumber = cardTextField.getText();
            String pinnumber = new String(pinTextField.getPassword());

            try{
                Conn conn = new Conn();

                String query =
                "SELECT * FROM login WHERE cardnumber='"+cardnumber+"' AND pin='"+pinnumber+"'";

                ResultSet rs = conn.s.executeQuery(query);

                if(rs.next()){
                    setVisible(false);
                    new Transactions(pinnumber);
                }else{
                    JOptionPane.showMessageDialog(null,"Incorrect Card Number or PIN");
                }

            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Database Error");
                e.printStackTrace();
            }
        }

        else if(ae.getSource()==signup){
            setVisible(false);
            new SignupOne();
        }
    }

    public static void main(String args[]){
        new LOGIN();
    }
}